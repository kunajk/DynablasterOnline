export class GameState_Fade
{
    Update(DeltaTime)
    {

    }

    Draw()
    {

    }
}