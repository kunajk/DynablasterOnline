export class GameState_Game
{
    Update(DeltaTime)
    {

    }

    Draw()
    {

    }
}