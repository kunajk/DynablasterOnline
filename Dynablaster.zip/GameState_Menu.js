export class GameState_Menu
{
    Update(DeltaTime)
    {

    }

    Draw()
    {

    }
}
